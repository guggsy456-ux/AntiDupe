package com.example.secureinventories;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;

public final class FlagFileLogger {

    private final JavaPlugin plugin;
    private final File file;

    public FlagFileLogger(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "flags.log");
    }

    public void logLine(String line) {
        try {
            plugin.getDataFolder().mkdirs();
            try (FileWriter fw = new FileWriter(file, true)) {
                fw.write("[" + Instant.now() + "] " + line + System.lineSeparator());
            }
        } catch (IOException e) {
            plugin.getLogger().warning("[SecureInventories] Could not write flags.log: " + e.getMessage());
        }
    }
}
