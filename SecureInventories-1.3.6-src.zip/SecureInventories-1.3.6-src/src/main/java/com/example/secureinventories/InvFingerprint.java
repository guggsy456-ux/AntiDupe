package com.example.secureinventories;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

public final class InvFingerprint {

    private final EnumMap<Material, Integer> counts;

    public InvFingerprint(EnumMap<Material, Integer> counts) {
        this.counts = counts;
    }

    public static InvFingerprint capture(Player p, Set<Material> ignore, boolean deepScanShulkers, boolean includeEnderChestShulkers) {
        EnumMap<Material, Integer> map = new EnumMap<>(Material.class);

        add(map, p.getInventory().getContents(), ignore, deepScanShulkers);

        if (includeEnderChestShulkers) {
            add(map, p.getEnderChest().getContents(), ignore, deepScanShulkers);
        } else {
            add(map, p.getEnderChest().getContents(), ignore, false);
        }

        return new InvFingerprint(map);
    }

    private static void add(EnumMap<Material, Integer> map, ItemStack[] items, Set<Material> ignore, boolean deepScanShulkers) {
        if (items == null) return;
        for (ItemStack it : items) {
            if (it == null) continue;
            Material m = it.getType();
            if (m.isAir()) continue;
            if (ignore != null && ignore.contains(m)) continue;

            map.merge(m, it.getAmount(), Integer::sum);

            if (deepScanShulkers && DeepScanUtil.isShulker(it)) {
                DeepScanUtil.addShulkerContents(map, it, ignore);
            }
        }
    }

    public static EnumMap<Material, Integer> delta(InvFingerprint after, InvFingerprint before) {
        EnumMap<Material, Integer> d = new EnumMap<>(Material.class);
        for (Map.Entry<Material, Integer> e : after.counts.entrySet()) {
            Material m = e.getKey();
            int a = e.getValue();
            int b = before.counts.getOrDefault(m, 0);
            int diff = a - b;
            if (diff != 0) d.put(m, diff);
        }
        for (Map.Entry<Material, Integer> e : before.counts.entrySet()) {
            Material m = e.getKey();
            if (after.counts.containsKey(m)) continue;
            d.put(m, -e.getValue());
        }
        return d;
    }
}
