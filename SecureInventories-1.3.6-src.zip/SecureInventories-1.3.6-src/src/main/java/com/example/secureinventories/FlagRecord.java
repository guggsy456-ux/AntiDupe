package com.example.secureinventories;

import org.bukkit.Location;

import java.time.Instant;
import java.util.Map;

public record FlagRecord(
        Instant at,
        String playerName,
        Location location,
        String inventoryType,
        int totalDeltaPositive,
        int totalUnexpected,
        Map<String, Integer> topUnexpectedMaterials,
        boolean conservationTriggered
) {}
