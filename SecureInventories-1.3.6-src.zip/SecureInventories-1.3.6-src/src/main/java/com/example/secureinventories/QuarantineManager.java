package com.example.secureinventories;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class QuarantineManager {

    public static final String META_QUARANTINED = "secureinventories_quarantined";

    private final JavaPlugin plugin;
    private final boolean enabled;
    private final boolean applyEffects;
    private final boolean setGamemode;
    private final GameMode gamemode;

    public QuarantineManager(JavaPlugin plugin, boolean enabled, boolean applyEffects, boolean setGamemode, GameMode gamemode) {
        this.plugin = plugin;
        this.enabled = enabled;
        this.applyEffects = applyEffects;
        this.setGamemode = setGamemode;
        this.gamemode = gamemode;
    }

    public void mark(Player p, boolean quarantined) {
        if (quarantined) {
            p.setMetadata(META_QUARANTINED, new FixedMetadataValue(plugin, true));
            if (setGamemode && gamemode != null) p.setGameMode(gamemode);
            if (applyEffects) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 60 * 60, 10, false, false, false));
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 20 * 60 * 60, 250, false, false, false));
            }
        } else {
            p.removeMetadata(META_QUARANTINED, plugin);
            if (applyEffects) {
                p.removePotionEffect(PotionEffectType.SLOWNESS);
                p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            }
        }
    }

    public boolean isQuarantined(Player p) {
        return enabled && p.hasMetadata(META_QUARANTINED);
    }
}
