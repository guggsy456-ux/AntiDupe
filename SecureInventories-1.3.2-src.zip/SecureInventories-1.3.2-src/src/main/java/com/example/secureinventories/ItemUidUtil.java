package com.example.secureinventories;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

public final class ItemUidUtil {

    private ItemUidUtil() {}

    public static NamespacedKey key(JavaPlugin plugin) {
        return new NamespacedKey(plugin, "secureinventories_uid");
    }

    public static String getUid(JavaPlugin plugin, ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return null;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return null;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        return pdc.get(key(plugin), PersistentDataType.STRING);
    }

    public static boolean hasUid(JavaPlugin plugin, ItemStack stack) {
        return getUid(plugin, stack) != null;
    }

    public static boolean shouldTag(ItemStack stack, boolean onlySinglesOrNonStackables, Set<Material> alwaysTag) {
        if (stack == null || stack.getType().isAir()) return false;
        if (alwaysTag != null && alwaysTag.contains(stack.getType())) return true;

        boolean nonStackable = stack.getMaxStackSize() == 1;
        if (nonStackable) return true;

        if (!onlySinglesOrNonStackables) return true;

        // stackable: only tag when amount == 1
        return stack.getAmount() == 1;
    }

    public static boolean ensureUid(JavaPlugin plugin, ItemStack stack, boolean onlySinglesOrNonStackables, Set<Material> alwaysTag) {
        if (!shouldTag(stack, onlySinglesOrNonStackables, alwaysTag)) return false;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey k = key(plugin);

        if (pdc.has(k, PersistentDataType.STRING)) return false;

        pdc.set(k, PersistentDataType.STRING, UUID.randomUUID().toString());
        stack.setItemMeta(meta);
        return true;
    }
}
