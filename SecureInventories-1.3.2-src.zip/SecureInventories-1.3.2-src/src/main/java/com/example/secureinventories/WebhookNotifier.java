package com.example.secureinventories;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class WebhookNotifier {

    private final JavaPlugin plugin;
    private final String url;
    private final String username;

    public WebhookNotifier(JavaPlugin plugin, String url, String username) {
        this.plugin = plugin;
        this.url = url;
        this.username = username;
    }

    public boolean enabled() {
        return url != null && !url.isBlank();
    }

    public void sendAsync(String content) {
        if (!enabled()) return;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> send(content));
    }

    private void send(String content) {
        try {
            String json = "{"
                    + "\"username\":\"" + escape(username) + "\","
                    + "\"content\":\"" + escape(content) + "\""
                    + "}";

            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            byte[] data = json.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(data.length);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(data);
            }

            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                plugin.getLogger().warning("[SecureInventories] Webhook non-2xx response: " + code);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("[SecureInventories] Webhook send failed: " + e.getMessage());
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
