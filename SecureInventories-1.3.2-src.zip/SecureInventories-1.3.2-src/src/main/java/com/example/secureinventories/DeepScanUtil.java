package com.example.secureinventories;

import org.bukkit.Material;
import org.bukkit.block.ShulkerBox;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;

import java.util.EnumMap;
import java.util.Set;

public final class DeepScanUtil {

    private DeepScanUtil() {}

    public static boolean isShulker(ItemStack it) {
        if (it == null) return false;
        return it.getType().name().endsWith("SHULKER_BOX");
    }

    public static void addShulkerContents(EnumMap<Material, Integer> map, ItemStack shulkerItem, Set<Material> ignore) {
        if (shulkerItem == null) return;
        if (!isShulker(shulkerItem)) return;
        if (!(shulkerItem.getItemMeta() instanceof BlockStateMeta bsm)) return;
        if (!(bsm.getBlockState() instanceof ShulkerBox box)) return;

        ItemStack[] contents = box.getInventory().getContents();
        if (contents == null) return;

        for (ItemStack it : contents) {
            if (it == null) continue;
            Material m = it.getType();
            if (m.isAir()) continue;
            if (ignore != null && ignore.contains(m)) continue;
            map.merge(m, it.getAmount(), Integer::sum);
        }
    }
}
