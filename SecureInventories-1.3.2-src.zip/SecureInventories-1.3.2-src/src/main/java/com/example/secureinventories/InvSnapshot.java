package com.example.secureinventories;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class InvSnapshot {
    private final ItemStack[] inventory;
    private final ItemStack[] enderChest;

    public InvSnapshot(ItemStack[] inventory, ItemStack[] enderChest) {
        this.inventory = deepClone(inventory);
        this.enderChest = deepClone(enderChest);
    }

    public static InvSnapshot capture(Player p) {
        return new InvSnapshot(p.getInventory().getContents(), p.getEnderChest().getContents());
    }

    public void restore(Player p) {
        p.getInventory().setContents(deepClone(inventory));
        p.getEnderChest().setContents(deepClone(enderChest));
        p.updateInventory();
    }

    private static ItemStack[] deepClone(ItemStack[] in) {
        if (in == null) return null;
        ItemStack[] out = new ItemStack[in.length];
        for (int i = 0; i < in.length; i++) {
            ItemStack it = in[i];
            out[i] = (it == null) ? null : it.clone();
        }
        return out;
    }
}
