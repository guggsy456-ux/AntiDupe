package com.example.secureinventories;

import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class SecureInventoriesListener implements Listener {

    private final JavaPlugin plugin;
    private final FlagFileLogger fileLogger;

    // Runtime config cache
    private Set<String> worldsIgnore = Set.of();
    private Set<InventoryType> invIgnore = Set.of();
    private Set<Material> materialsIgnore = Set.of();

    private int minMatFlag;
    private int minTotalFlag;
    private int tolMat;
    private int tolTotal;
    private boolean snapshotAll;
    private boolean notifyStaff;
    private int notifyCooldownSeconds;
    private boolean fileLogging;
    private String action;

    // Hard: conservation ledger
    private boolean ledgerEnabled;
    private boolean includeContainerConservation;

    // Hard: deep scan shulkers
    private boolean deepScanEnabled;
    private boolean deepScanEnder;

    // Monitor mode
    private boolean monitorEnabled;
    private int monitorMinutes;
    private int monitorMinMatFlag;
    private int monitorMinTotalFlag;
    private int monitorTolMat;
    private int monitorTolTotal;

    // Quit handling
    private boolean rollbackOnQuit;

    // Heuristics
    private boolean rapidEnabled;
    private int rapidWindowSeconds;
    private int rapidMaxCloses;

    // Strikes/quarantine
    private boolean strikesEnabled;
    private int maxStrikesBeforeQuarantine;
    private int strikeDecayMinutes;

    private boolean quarantineEnabled;
    private String quarantineWorld;
    private double quarantineX, quarantineY, quarantineZ;

    // Restrict while quarantined
    private boolean restrictEnabled;
    private boolean denyCommands;
    private boolean denyInventoryMove;
    private boolean denyItemDrop;
    private boolean denyItemPickup;
    private boolean denyBlockInteract;
    private boolean applyEffects;
    private GameMode quarantineGamemode;

    // Webhook
    private String webhookUrl;
    private boolean webhookFlag;
    private boolean webhookQuarantine;
    private String webhookUsername;
    // Item UID scan ("Item ID duplication")
    private boolean idScanEnabled;
    private boolean tagExistingOnJoin;
    private boolean tagOnPickup;
    private boolean tagOnCraft;
    private boolean tagOnInventoryClose;
    private boolean onlyTagSinglesOrNonStackables;
    private Set<Material> alwaysTagMaterials = Set.of();
    private String duplicateUidAction;

    private static final class Session {
        final InvSnapshot snapshot;
        final InvFingerprint beforePlayer;
        final ContainerFingerprint beforeContainer;
        final long startedAtMs;

        // “External” legit gain sources while the container is open:
        // pickups, crafts, furnace extracts
        final EnumMap<Material, Integer> externalLegitGain = new EnumMap<>(Material.class);

        // Rapid close/open heuristic
        int closesInWindow = 0;
        long windowStartMs = 0;

        Session(InvSnapshot snapshot, InvFingerprint beforePlayer, ContainerFingerprint beforeContainer) {
            this.snapshot = snapshot;
            this.beforePlayer = beforePlayer;
            this.beforeContainer = beforeContainer;
            this.startedAtMs = System.currentTimeMillis();
        }

        void addExternalLegit(Material m, int amount) {
            if (m == null || m.isAir() || amount <= 0) return;
            externalLegitGain.merge(m, amount, Integer::sum);
        }
    }

    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();

    // Staff notify cooldown per flagged player
    private final Map<UUID, Long> lastStaffNotifyMs = new ConcurrentHashMap<>();

    // Strikes + monitor
    private final Map<UUID, Deque<Long>> strikeTimesMs = new ConcurrentHashMap<>();
    private final Map<UUID, Long> monitorUntilMs = new ConcurrentHashMap<>();

    // Recent flags/snapshots (since restart)
    private final Map<UUID, Deque<FlagRecord>> recentFlags = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<InvSnapshot>> recentSnapshots = new ConcurrentHashMap<>();

    public SecureInventoriesListener(JavaPlugin plugin) {
        this.plugin = plugin;
        this.fileLogger = new FlagFileLogger(plugin);
        reloadRuntimeConfig();
    }

    public void reloadRuntimeConfig() {
        worldsIgnore = new HashSet<>(plugin.getConfig().getStringList("worldsIgnore"));

        Set<InventoryType> inv = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("inventoryTypesIgnore")) {
            try { inv.add(InventoryType.valueOf(s.toUpperCase(Locale.ROOT))); } catch (IllegalArgumentException ignored) {}
        }
        invIgnore = inv;

        Set<Material> mats = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("materialsIgnore")) {
            try { mats.add(Material.valueOf(s.toUpperCase(Locale.ROOT))); } catch (IllegalArgumentException ignored) {}
        }
        materialsIgnore = mats;

        minMatFlag = plugin.getConfig().getInt("minUnexpectedIncreasePerMaterialToFlag", 16);
        minTotalFlag = plugin.getConfig().getInt("minUnexpectedIncreaseTotalToFlag", 32);
        tolMat = plugin.getConfig().getInt("tolerancePerMaterial", 4);
        tolTotal = plugin.getConfig().getInt("toleranceTotal", 8);

        snapshotAll = plugin.getConfig().getBoolean("snapshotAllInventories", true);
        notifyStaff = plugin.getConfig().getBoolean("notifyStaff", true);
        notifyCooldownSeconds = plugin.getConfig().getInt("staffNotifyCooldownSeconds", 10);
        fileLogging = plugin.getConfig().getBoolean("fileLogging", true);
        action = plugin.getConfig().getString("action", "ROLLBACK").toUpperCase(Locale.ROOT);

        ledgerEnabled = plugin.getConfig().getBoolean("ledger.enabled", true);
        includeContainerConservation = plugin.getConfig().getBoolean("ledger.includeContainerConservation", true);

        deepScanEnabled = plugin.getConfig().getBoolean("deepScanShulkers.enabled", true);
        deepScanEnder = plugin.getConfig().getBoolean("deepScanShulkers.includeEnderChest", true);

        monitorEnabled = plugin.getConfig().getBoolean("monitorMode.enabled", true);
        monitorMinutes = plugin.getConfig().getInt("monitorMode.minutes", 5);
        monitorMinMatFlag = plugin.getConfig().getInt("monitorMode.minUnexpectedIncreasePerMaterialToFlag", 8);
        monitorMinTotalFlag = plugin.getConfig().getInt("monitorMode.minUnexpectedIncreaseTotalToFlag", 16);
        monitorTolMat = plugin.getConfig().getInt("monitorMode.tolerancePerMaterial", 2);
        monitorTolTotal = plugin.getConfig().getInt("monitorMode.toleranceTotal", 4);

        rollbackOnQuit = plugin.getConfig().getBoolean("rollbackOnQuitWithSession", false);

        rapidEnabled = plugin.getConfig().getBoolean("heuristics.rapidOpenClose.enabled", true);
        rapidWindowSeconds = plugin.getConfig().getInt("heuristics.rapidOpenClose.windowSeconds", 10);
        rapidMaxCloses = plugin.getConfig().getInt("heuristics.rapidOpenClose.maxClosesInWindow", 8);

        strikesEnabled = plugin.getConfig().getBoolean("strikes.enabled", true);
        maxStrikesBeforeQuarantine = plugin.getConfig().getInt("strikes.maxStrikesBeforeQuarantine", 3);
        strikeDecayMinutes = plugin.getConfig().getInt("strikes.decayMinutes", 60);

        quarantineEnabled = plugin.getConfig().getBoolean("quarantine.enabled", false);
        quarantineWorld = plugin.getConfig().getString("quarantine.world", "spawn");
        quarantineX = plugin.getConfig().getDouble("quarantine.location.x", 0.5);
        quarantineY = plugin.getConfig().getDouble("quarantine.location.y", 100.0);
        quarantineZ = plugin.getConfig().getDouble("quarantine.location.z", 0.5);

        restrictEnabled = plugin.getConfig().getBoolean("quarantine.restrict.enabled", true);
        denyCommands = plugin.getConfig().getBoolean("quarantine.restrict.denyCommands", true);
        denyInventoryMove = plugin.getConfig().getBoolean("quarantine.restrict.denyInventoryMove", true);
        denyItemDrop = plugin.getConfig().getBoolean("quarantine.restrict.denyItemDrop", true);
        denyItemPickup = plugin.getConfig().getBoolean("quarantine.restrict.denyItemPickup", true);
        denyBlockInteract = plugin.getConfig().getBoolean("quarantine.restrict.denyBlockInteract", true);
        applyEffects = plugin.getConfig().getBoolean("quarantine.restrict.applyEffects", true);

        String gm = plugin.getConfig().getString("quarantine.restrict.setGamemode", "ADVENTURE");
        try { quarantineGamemode = GameMode.valueOf(gm.toUpperCase(Locale.ROOT)); }
        catch (Exception e) { quarantineGamemode = GameMode.ADVENTURE; }

        webhookUrl = plugin.getConfig().getString("webhook.url", "");
        webhookFlag = plugin.getConfig().getBoolean("webhook.notifyOnFlag", false);
        webhookQuarantine = plugin.getConfig().getBoolean("webhook.notifyOnQuarantine", false);
        webhookUsername = plugin.getConfig().getString("webhook.username", "AntiDupeLite");

        webhook = new WebhookNotifier(plugin, webhookUrl, webhookUsername);
        quarantineManager = new QuarantineManager(plugin, restrictEnabled, applyEffects, true, quarantineGamemode);
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("enabled", true);
    }

    private boolean isIgnoredWorld(Player p) {
        return worldsIgnore.contains(p.getWorld().getName());
    }

    // ------------------------
    // Session capture / close
    // ------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (!enabled()) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        if (isIgnoredWorld(p)) return;

        Inventory top = e.getInventory();
        if (!shouldSnapshot(top)) return;

        InvSnapshot snap = InvSnapshot.capture(p);
        InvFingerprint beforePlayer = InvFingerprint.capture(p, materialsIgnore, deepScanEnabled, deepScanEnder);
        ContainerFingerprint beforeCont = ContainerFingerprint.capture(top, materialsIgnore);

        sessions.put(p.getUniqueId(), new Session(snap, beforePlayer, beforeCont));

        if (plugin.getConfig().getBoolean("debug", false)) {
            plugin.getLogger().info("[DEBUG] Captured session for " + p.getName() + " inv=" + top.getType());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClose(InventoryCloseEvent e) {
        if (!enabled()) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        if (isIgnoredWorld(p)) return;

        Session s = sessions.remove(p.getUniqueId());
        if (s == null) return;
        if (invIgnore.contains(e.getInventory().getType())) return;

        // Item UID tagging + duplicate UID scan
        if (idScanEnabled && tagOnInventoryClose) {
            tagAllPlayerItems(p);
        }
        if (idScanEnabled) {
            Map<String, Integer> dups = scanDuplicateUids(p);
            if (!dups.isEmpty()) {
                handleDuplicateUidDetection(p, e.getInventory(), dups, s.snapshot);
                // If action was rollback/kick/remove duplicates, we still continue with ledger checks
                // because a duped item may also create unexpected deltas.
            }
        }


        // Heuristic: rapid close/open spam (log only)
        if (rapidEnabled) {
            long now = System.currentTimeMillis();
            if (s.windowStartMs == 0 || now - s.windowStartMs > rapidWindowSeconds * 1000L) {
                s.windowStartMs = now;
                s.closesInWindow = 0;
            }
            s.closesInWindow++;
            if (s.closesInWindow >= rapidMaxCloses) {
                plugin.getLogger().warning("[SecureInventories] " + p.getName() + " is rapidly closing inventories (" +
                        s.closesInWindow + " in ~" + rapidWindowSeconds + "s).");
            }
        }

        InvFingerprint afterPlayer = InvFingerprint.capture(p, materialsIgnore, deepScanEnabled, deepScanEnder);
        EnumMap<Material, Integer> playerDelta = InvFingerprint.delta(afterPlayer, s.beforePlayer);

        ContainerFingerprint afterCont = ContainerFingerprint.capture(e.getInventory(), materialsIgnore);
        EnumMap<Material, Integer> contDelta = ContainerFingerprint.delta(afterCont, s.beforeContainer);

        // Hard: conservation check:
        // unexpected = playerPositiveGain - (externalLegit + removedFromContainer + tolMat)
        EnumMap<Material, Integer> unexpectedPerMat = new EnumMap<>(Material.class);
        int totalDeltaPositive = 0;
        int totalUnexpected = 0;

        for (Map.Entry<Material, Integer> de : playerDelta.entrySet()) {
            Material m = de.getKey();
            int d = de.getValue();
            if (d <= 0) continue;
            totalDeltaPositive += d;

            int external = s.externalLegitGain.getOrDefault(m, 0);

            int removedFromContainer = 0;
            if (ledgerEnabled && includeContainerConservation) {
                int cd = contDelta.getOrDefault(m, 0);
                // container decreased => negative delta => removed = -cd
                if (cd < 0) removedFromContainer = -cd;
            }

            int allowed = external + removedFromContainer + currentTolMat(p);
            int unexpected = d - allowed;
            if (unexpected > 0) {
                unexpectedPerMat.put(m, unexpected);
                totalUnexpected += unexpected;
            }
        }

        boolean perMatFlag = unexpectedPerMat.values().stream().anyMatch(v -> v >= currentMinMatFlag(p));
        boolean totalFlag = (totalUnexpected - currentTolTotal(p)) >= currentMinTotalFlag(p);

        if (plugin.getConfig().getBoolean("debug", false)) {
            plugin.getLogger().info("[DEBUG] " + p.getName()
                    + " totalDeltaPos=" + totalDeltaPositive
                    + " totalUnexpected=" + totalUnexpected
                    + " perMatFlag=" + perMatFlag
                    + " totalFlag=" + totalFlag
                    + " conservation=" + (ledgerEnabled && includeContainerConservation)
                    + " deepScan=" + deepScanEnabled);
        }

        if (perMatFlag || totalFlag) {
            boolean conservationTriggered = (ledgerEnabled && includeContainerConservation);
            flagAndAct(p, e.getInventory(), totalDeltaPositive, totalUnexpected, unexpectedPerMat, s.snapshot, conservationTriggered);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        if (!enabled()) return;
        Player p = e.getPlayer();
        if (!idScanEnabled || !tagExistingOnJoin) return;

        // Tag items already owned so future duplication is detectable
        tagAllPlayerItems(p);
    }

    }

    // ------------------------
    // Ledger: external legit sources
    // ------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (!enabled()) return;
        if (!(e.getEntity() instanceof Player p)) return;
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return;
                if (idScanEnabled && tagOnPickup) {
            ItemUidUtil.ensureUid(plugin, stack, onlyTagSinglesOrNonStackables, alwaysTagMaterials);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        if (!enabled()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return;

        ItemStack result = e.getCurrentItem();
        if (result == null || result.getType().isAir()) return;

        int amt = Math.max(1, result.getAmount());
        // Shift-click can produce many. We intentionally over-allow to reduce false positives.
        if (e.isShiftClick()) amt = Math.min(amt * 32, 64 * 64);

        s.addExternalLegit(result.getType(), amt);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFurnaceExtract(FurnaceExtractEvent e) {
        if (!enabled()) return;
        Player p = e.getPlayer();
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return;
        s.addExternalLegit(e.getItemType(), Math.max(1, e.getItemAmount()));
    }

    // ------------------------
    // Quarantine restrictions
    // ------------------------

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!restrictEnabled || !denyCommands) return;
        Player p = e.getPlayer();
        if (!quarantineManager.isQuarantined(p)) return;
        if (p.hasPermission("secureinventories.admin")) return;

        e.setCancelled(true);
        p.sendMessage(SecureInventories.color("&cYou cannot use commands while quarantined."));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!restrictEnabled || !denyInventoryMove) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!quarantineManager.isQuarantined(p)) return;
        if (p.hasPermission("secureinventories.admin")) return;

        e.setCancelled(true);
        p.sendMessage(SecureInventories.color("&cInventory access is restricted while quarantined."));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDropRestrict(PlayerDropItemEvent e) {
        if (!restrictEnabled || !denyItemDrop) return;
        Player p = e.getPlayer();
        if (!quarantineManager.isQuarantined(p)) return;
        if (p.hasPermission("secureinventories.admin")) return;

        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickupRestrict(EntityPickupItemEvent e) {
        if (!restrictEnabled || !denyItemPickup) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (!quarantineManager.isQuarantined(p)) return;
        if (p.hasPermission("secureinventories.admin")) return;

        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (!restrictEnabled || !denyBlockInteract) return;
        Player p = e.getPlayer();
        if (!quarantineManager.isQuarantined(p)) return;
        if (p.hasPermission("secureinventories.admin")) return;

        Action a = e.getAction();
        if (a == Action.RIGHT_CLICK_BLOCK || a == Action.LEFT_CLICK_BLOCK
                || a == Action.RIGHT_CLICK_AIR || a == Action.LEFT_CLICK_AIR) {
            e.setCancelled(true);
        }
    }
    private void tagAllPlayerItems(Player p) {
        // Inventory
        for (ItemStack it : p.getInventory().getContents()) {
            ItemUidUtil.ensureUid(plugin, it, onlyTagSinglesOrNonStackables, alwaysTagMaterials);
        }
        // Ender chest
        for (ItemStack it : p.getEnderChest().getContents()) {
            ItemUidUtil.ensureUid(plugin, it, onlyTagSinglesOrNonStackables, alwaysTagMaterials);
        }
    }

    private Map<String, Integer> scanDuplicateUids(Player p) {
        Map<String, Integer> counts = new HashMap<>();

        for (ItemStack it : p.getInventory().getContents()) {
            String uid = ItemUidUtil.getUid(plugin, it);
            if (uid != null) counts.merge(uid, 1, Integer::sum);
        }
        for (ItemStack it : p.getEnderChest().getContents()) {
            String uid = ItemUidUtil.getUid(plugin, it);
            if (uid != null) counts.merge(uid, 1, Integer::sum);
        }

        // return only duplicates
        Map<String, Integer> dups = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            if (e.getValue() >= 2) dups.put(e.getKey(), e.getValue());
        }
        return dups;
    }

    private void handleDuplicateUidDetection(Player p, Inventory container, Map<String, Integer> dups, InvSnapshot snapshot) {
        if (dups.isEmpty()) return;

        String invType = container.getType().name();
        int dupCount = dups.size();

        String msg = "[SecureInventories] Duplicate Item UID(s) detected for " + p.getName()
                + " inv=" + invType
                + " world=" + p.getWorld().getName()
                + " dupUids=" + dupCount
                + " sample=" + dups.keySet().stream().limit(5).toList();

        plugin.getLogger().warning(msg);
        if (fileLogging) fileLogger.logLine(msg);

        if (notifyStaff && shouldNotifyStaff(p.getUniqueId())) {
            String staffMsg = ChatColor.RED + msg;
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.hasPermission("secureinventories.alert")) {
                    online.sendMessage(staffMsg);
                }
            }
        }

        // Actions for duplicate UIDs
        switch (duplicateUidAction) {
            case "REMOVE_DUPLICATES" -> {
                removeDuplicateUidItems(p, dups);
                p.sendMessage(SecureInventories.color("&cDuplicate item IDs detected. Duplicates removed."));
            }
            case "ROLLBACK" -> {
                snapshot.restore(p);
                p.sendMessage(SecureInventories.color("&cDuplicate item IDs detected. Inventory rolled back."));
            }
            case "ROLLBACK_AND_KICK" -> {
                snapshot.restore(p);
                p.kickPlayer(SecureInventories.color("&cDuplicate item IDs detected. Inventory rolled back."));
            }
            case "FLAG" -> {
                // do nothing further (already logged + staff notified). Strikes/monitor applies via existing path if desired.
                enterMonitorMode(p);
                addStrike(p);
            }
            default -> {
                enterMonitorMode(p);
                addStrike(p);
            }
        }
    }

    private void removeDuplicateUidItems(Player p, Map<String, Integer> dups) {
        // Remove all but one instance per UID across inv + ender
        Map<String, Integer> remaining = new HashMap<>();
        for (String uid : dups.keySet()) remaining.put(uid, 1);

        // inventory
        ItemStack[] inv = p.getInventory().getContents();
        for (int i = 0; i < inv.length; i++) {
            ItemStack it = inv[i];
            String uid = ItemUidUtil.getUid(plugin, it);
            if (uid == null) continue;
            if (!remaining.containsKey(uid)) continue;

            int left = remaining.get(uid);
            if (left > 0) {
                remaining.put(uid, left - 1);
            } else {
                inv[i] = null;
            }
        }
        p.getInventory().setContents(inv);

        // ender chest
        ItemStack[] ec = p.getEnderChest().getContents();
        for (int i = 0; i < ec.length; i++) {
            ItemStack it = ec[i];
            String uid = ItemUidUtil.getUid(plugin, it);
            if (uid == null) continue;
            if (!remaining.containsKey(uid)) continue;

            int left = remaining.get(uid);
            if (left > 0) {
                remaining.put(uid, left - 1);
            } else {
                ec[i] = null;
            }
        }
        p.getEnderChest().setContents(ec);
        p.updateInventory();
    }



    // ------------------------
    // Threshold helpers
    // ------------------------

    private int currentMinMatFlag(Player p) { return isInMonitorMode(p) ? monitorMinMatFlag : minMatFlag; }
    private int currentMinTotalFlag(Player p) { return isInMonitorMode(p) ? monitorMinTotalFlag : minTotalFlag; }
    private int currentTolMat(Player p) { return isInMonitorMode(p) ? monitorTolMat : tolMat; }
    private int currentTolTotal(Player p) { return isInMonitorMode(p) ? monitorTolTotal : tolTotal; }

    private boolean isInMonitorMode(Player p) {
        if (!monitorEnabled) return false;
        Long until = monitorUntilMs.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    private void enterMonitorMode(Player p) {
        if (!monitorEnabled) return;
        monitorUntilMs.put(p.getUniqueId(), System.currentTimeMillis() + monitorMinutes * 60_000L);
    }

    // ------------------------
    // Strikes + quarantine
    // ------------------------

    private void addStrike(Player p) {
        if (!strikesEnabled) return;
        long now = System.currentTimeMillis();

        Deque<Long> q = strikeTimesMs.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        q.addLast(now);

        long cutoff = now - strikeDecayMinutes * 60_000L;
        while (!q.isEmpty() && q.peekFirst() < cutoff) q.removeFirst();

        int strikes = q.size();
        plugin.getLogger().warning("[SecureInventories] " + p.getName() + " strikes=" + strikes + "/" + maxStrikesBeforeQuarantine);

        if (quarantineEnabled && strikes >= maxStrikesBeforeQuarantine) {
            quarantine(p, "auto");
        }
    }

    private void quarantine(Player p, String reason) {
        World w = Bukkit.getWorld(quarantineWorld);
        if (w == null) {
            plugin.getLogger().warning("[SecureInventories] Quarantine world not found: " + quarantineWorld);
            return;
        }

        Location loc = new Location(w, quarantineX, quarantineY, quarantineZ);
        p.teleport(loc);

        quarantineManager.mark(p, true);

        p.sendMessage(SecureInventories.color("&cYou have been moved for review due to duplication flags."));
        plugin.getLogger().warning("[SecureInventories] Quarantined " + p.getName() + " (" + reason + ") to " + quarantineWorld);

        if (webhook.enabled() && webhookQuarantine) {
            webhook.sendAsync("Quarantined **" + p.getName() + "** (" + reason + ") in `" + quarantineWorld + "`.");
        }
    }

    public void forceQuarantine(Player p, String by) {
        quarantine(p, "manual by " + by);
    }

    public void unquarantine(Player p, String by) {
        quarantineManager.mark(p, false);
        p.sendMessage(SecureInventories.color("&aYou have been released from quarantine."));
        plugin.getLogger().info("[SecureInventories] Unquarantined " + p.getName() + " by " + by);
    }

    // ------------------------
    // Flag + actions
    // ------------------------

    private void pushRecent(UUID uuid, FlagRecord rec, InvSnapshot snapshot) {
        recentFlags.computeIfAbsent(uuid, k -> new ArrayDeque<>()).addLast(rec);
        recentSnapshots.computeIfAbsent(uuid, k -> new ArrayDeque<>()).addLast(snapshot);

        while (recentFlags.get(uuid).size() > 5) recentFlags.get(uuid).removeFirst();
        while (recentSnapshots.get(uuid).size() > 5) recentSnapshots.get(uuid).removeFirst();
    }

    private void flagAndAct(Player p, Inventory container, int totalDeltaPositive, int totalUnexpected,
                            EnumMap<Material, Integer> unexpectedPerMat, InvSnapshot snapshot, boolean conservationTriggered) {

        String invType = container.getType().name();
        Map<String, Integer> top = topUnexpected(unexpectedPerMat, 10);

        String tps = readTpsSafe();
        int ping = safePing(p);

        String msg = "[SecureInventories] Flagged " + p.getName()
                + " inv=" + invType
                + " world=" + p.getWorld().getName()
                + " loc=" + p.getLocation().getBlockX() + "," + p.getLocation().getBlockY() + "," + p.getLocation().getBlockZ()
                + " ping=" + ping
                + " tps=" + tps
                + " deltaPos=" + totalDeltaPositive
                + " unexpected=" + totalUnexpected
                + " conservation=" + (ledgerEnabled && includeContainerConservation)
                + " deepScan=" + deepScanEnabled
                + " top=" + top;

        plugin.getLogger().warning(msg);
        if (fileLogging) fileLogger.logLine(msg);

        pushRecent(
                p.getUniqueId(),
                new FlagRecord(Instant.now(), p.getName(), p.getLocation(), invType, totalDeltaPositive, totalUnexpected, top, conservationTriggered),
                snapshot
        );

        // Staff notify (cooldown)
        if (notifyStaff && shouldNotifyStaff(p.getUniqueId())) {
            String staffMsg = ChatColor.RED + msg;
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.hasPermission("secureinventories.alert")) {
                    online.sendMessage(staffMsg);
                }
            }
        }

        // Optional webhook notify
        if (webhook.enabled() && webhookFlag) {
            webhook.sendAsync("Flagged **" + p.getName() + "** inv=`" + invType + "` unexpected=`" + totalUnexpected + "` top=" + top);
        }

        // Monitor mode + strikes
        enterMonitorMode(p);
        addStrike(p);

        // Actions
        if (action.equals("LOG")) return;

        boolean doRollback = action.equals("ROLLBACK") || action.equals("ROLLBACK_AND_KICK");
        boolean doKick = action.equals("KICK") || action.equals("ROLLBACK_AND_KICK");

        if (doRollback) {
            snapshot.restore(p);
            plugin.getLogger().warning("[SecureInventories] Rolled back inventory for " + p.getName());
        }

        if (doKick) {
            String kickMsg = SecureInventories.color(plugin.getConfig().getString(
                    "kickMessage",
                    "&cPossible duplication detected. Inventory rollback applied."
            ));
            p.kickPlayer(kickMsg);
        }
    }

    private boolean shouldNotifyStaff(UUID playerUuid) {
        long now = System.currentTimeMillis();
        long last = lastStaffNotifyMs.getOrDefault(playerUuid, 0L);
        if (now - last < notifyCooldownSeconds * 1000L) return false;
        lastStaffNotifyMs.put(playerUuid, now);
        return true;
    }

    private Map<String, Integer> topUnexpected(EnumMap<Material, Integer> unexpectedPerMat, int limit) {
        return unexpectedPerMat.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .collect(LinkedHashMap::new,
                        (m, e) -> m.put(e.getKey().name(), e.getValue()),
                        LinkedHashMap::putAll);
    }

    private String readTpsSafe() {
        try {
            double[] tps = Bukkit.getTPS();
            if (tps == null || tps.length == 0) return "n/a";
            return String.format(Locale.ROOT, "%.2f", tps[0]);
        } catch (Throwable t) {
            return "n/a";
        }
    }

    private int safePing(Player p) {
        try { return p.getPing(); } catch (Throwable t) { return -1; }
    }

    private boolean shouldSnapshot(Inventory inv) {
        if (invIgnore.contains(inv.getType())) return false;
        if (snapshotAll) return true;

        InventoryType t = inv.getType();
        return switch (t) {
            case CHEST, BARREL, SHULKER_BOX, HOPPER, DISPENSER, DROPPER,
                 FURNACE, BLAST_FURNACE, SMOKER, BREWING, ENCHANTING,
                 ANVIL, SMITHING, GRINDSTONE, LOOM, CARTOGRAPHY,
                 STONECUTTER, MERCHANT, BEACON -> true;
            default -> false;
        };
    }

    // ------------------------
    // Admin commands support
    // ------------------------

    public void sendInspect(CommandSender sender, Player target) {
        UUID u = target.getUniqueId();

        int strikes = getStrikes(u);
        boolean monitor = isInMonitorMode(target);
        boolean quarantined = quarantineManager.isQuarantined(target);

        sender.sendMessage(SecureInventories.color("&7[SecureInventories] &f" + target.getName()
                + " &7strikes=&f" + strikes
                + " &7monitor=&f" + monitor
                + " &7quarantined=&f" + quarantined));

        Deque<FlagRecord> flags = recentFlags.get(u);
        if (flags == null || flags.isEmpty()) {
            sender.sendMessage(SecureInventories.color("&7No recent flags recorded for this player (since last restart)."));
            return;
        }

        sender.sendMessage(SecureInventories.color("&7Recent flags (newest last):"));
        for (FlagRecord fr : flags) {
            sender.sendMessage(ChatColor.GRAY + " - " + fr.at()
                    + " inv=" + fr.inventoryType()
                    + " unexpected=" + fr.totalUnexpected()
                    + " conservationTriggered=" + fr.conservationTriggered()
                    + " top=" + fr.topUnexpectedMaterials());
        }
    }

    public void pardon(CommandSender sender, String playerNameOrUuid) {
        UUID u = resolveUuid(playerNameOrUuid);
        if (u == null) {
            sender.sendMessage(SecureInventories.color("&cCould not resolve player (must be online, or provide UUID)."));
            return;
        }
        strikeTimesMs.remove(u);
        monitorUntilMs.remove(u);
        sender.sendMessage(SecureInventories.color("&aCleared strikes/monitor for " + playerNameOrUuid));
    }

    public void rollbackCommand(CommandSender sender, String playerName, String mode) {
        Player target = Bukkit.getPlayerExact(playerName);
        if (target == null) {
            sender.sendMessage(SecureInventories.color("&cPlayer not online."));
            return;
        }
        Deque<InvSnapshot> snaps = recentSnapshots.get(target.getUniqueId());
        if (snaps == null || snaps.isEmpty()) {
            sender.sendMessage(SecureInventories.color("&cNo stored snapshots for this player (since last restart)."));
            return;
        }
        InvSnapshot snap = snaps.peekLast();
        snap.restore(target);
        sender.sendMessage(SecureInventories.color("&aRolled back " + target.getName() + " to last stored snapshot."));
    }

    private int getStrikes(UUID u) {
        Deque<Long> q = strikeTimesMs.get(u);
        if (q == null) return 0;
        long now = System.currentTimeMillis();
        long cutoff = now - strikeDecayMinutes * 60_000L;
        while (!q.isEmpty() && q.peekFirst() < cutoff) q.removeFirst();
        return q.size();
    }

    private UUID resolveUuid(String playerNameOrUuid) {
        try {
            return UUID.fromString(playerNameOrUuid);
        } catch (IllegalArgumentException ignored) {
            Player p = Bukkit.getPlayerExact(playerNameOrUuid);
            return (p != null) ? p.getUniqueId() : null;
        }
    }
}
