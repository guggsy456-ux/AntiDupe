SecureInventories 1.3.2 (Paper 1.21+)

What it does:
- Detects suspicious inventory gains during container sessions using a conservation/ledger rule
- Optional deep-scan of shulker contents (player inventory + ender chest)
- Optional strikes + quarantine workflow
- Optional webhook notifications

Build:
  mvn clean package

Jar output:
  target/SecureInventories-1.3.2.jar

Commands:
  /secureinventories status
  /secureinventories reload
  /secureinventories inspect <player>
  /secureinventories pardon <player|uuid>
  /secureinventories rollback <player> [last]
  /secureinventories quarantine <player>
  /secureinventories unquarantine <player>

Aliases:
  /si
  /antidupe  (compat alias)

Permissions:
  secureinventories.admin
  secureinventories.alert
