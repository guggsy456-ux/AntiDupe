package com.joinussmp.unicooldown.listeners;

import com.joinussmp.unicooldown.Text;
import com.joinussmp.unicooldown.cooldown.CooldownManager;
import com.joinussmp.unicooldown.cooldown.CooldownRule;
import com.joinussmp.unicooldown.cooldown.RuleRegistry;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class ItemCooldownListener implements Listener {
    private final Plugin plugin;
    private final CooldownManager cooldowns;
    private final RuleRegistry rules;

    public ItemCooldownListener(Plugin plugin, CooldownManager cooldowns, RuleRegistry rules) {
        this.plugin = plugin;
        this.cooldowns = cooldowns;
        this.rules = rules;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (item == null) return;

        Material mat = item.getType();
        CooldownRule rule = rules.itemRule(mat);
        if (rule == null) return;

        Player player = event.getPlayer();
        String worldName = player.getWorld().getName();

        // global bypass
        if (player.hasPermission("unicooldown.bypass")) return;

        // world disable gate (blocks the interaction entirely)
        if (rule.isDisabledInWorld(worldName)) {
            if (rule.bypassPermission() != null && !rule.bypassPermission().isBlank() && player.hasPermission(rule.bypassPermission())) return;

            String prefix = plugin.getConfig().getString("messages.prefix", "");
            String text = (rule.disabledMessage() == null || rule.disabledMessage().isBlank())
                    ? plugin.getConfig().getString("messages.disabled-in-world", "&cYou cannot use that item in this world.")
                    : rule.disabledMessage();

            text = text.replace("%item%", mat.name())
                       .replace("%key%", rule.effectiveKey())
                       .replace("%world%", worldName);

            player.sendMessage(Text.color(prefix + text));
            event.setCancelled(true);
            return;
        }

        if (rule.bypassPermission() != null && !rule.bypassPermission().isBlank() && player.hasPermission(rule.bypassPermission())) return;

        String key = rule.effectiveKey();
        long remaining = cooldowns.remainingMillis(player.getUniqueId(), key);
        if (remaining > 0) {
            long secondsLeft = (long) Math.ceil(remaining / 1000.0);
            String prefix = plugin.getConfig().getString("messages.prefix", "");
            String text = (rule.message() == null || rule.message().isBlank())
                    ? plugin.getConfig().getString("messages.blocked-default", "&cPlease wait %time%s.")
                    : rule.message();

            text = text.replace("%time%", String.valueOf(secondsLeft))
                       .replace("%item%", mat.name())
                       .replace("%key%", key)
                       .replace("%world%", worldName);

            player.sendMessage(Text.color(prefix + text));
            event.setCancelled(true);
            return;
        }

        cooldowns.set(player.getUniqueId(), key, rule.durationMillis());
    }
}
