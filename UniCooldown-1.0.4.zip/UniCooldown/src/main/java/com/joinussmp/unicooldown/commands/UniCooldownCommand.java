package com.joinussmp.unicooldown.commands;

import com.joinussmp.unicooldown.Text;
import com.joinussmp.unicooldown.UniCooldownPlugin;
import com.joinussmp.unicooldown.cooldown.CooldownManager;
import com.joinussmp.unicooldown.cooldown.RuleRegistry;
import com.joinussmp.unicooldown.storage.CooldownStorage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Comparator;
import java.util.Map;
import java.util.UUID;

public final class UniCooldownCommand implements CommandExecutor {
    private final UniCooldownPlugin plugin;
    private final CooldownManager cooldowns;
    private final RuleRegistry rules;
    private final CooldownStorage storage;

    public UniCooldownCommand(UniCooldownPlugin plugin, CooldownManager cooldowns, RuleRegistry rules, CooldownStorage storage) {
        this.plugin = plugin;
        this.cooldowns = cooldowns;
        this.rules = rules;
        this.storage = storage;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("unicooldown.admin")) {
            msg(sender, plugin.getConfig().getString("messages.no-permission"));
            return true;
        }

        if (args.length == 0) {
            msg(sender, plugin.getConfig().getString("messages.unknown-subcommand"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadAll();
                msg(sender, plugin.getConfig().getString("messages.reloaded"));
                return true;
            }
            case "check" -> {
                if (args.length < 2) {
                    msg(sender, "&cUsage: /uc check <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    msg(sender, "&cPlayer not found.");
                    return true;
                }

                cooldowns.cleanupExpired();

                Map<String, Long> map = cooldowns.getAll(target.getUniqueId());
                if (map.isEmpty()) {
                    msg(sender, plugin.getConfig().getString("messages.check-none"));
                    return true;
                }

                String fmt = plugin.getConfig().getString("messages.check-format", "%key%: %time%s");
                long now = System.currentTimeMillis();

                map.entrySet().stream()
                        .sorted(Comparator.comparing(Map.Entry::getKey))
                        .forEach(e -> {
                            long rem = Math.max(0L, e.getValue() - now);
                            long sec = (long) Math.ceil(rem / 1000.0);
                            String line = fmt.replace("%key%", e.getKey()).replace("%time%", String.valueOf(sec));
                            msg(sender, line);
                        });

                return true;
            }
            case "list" -> {
                // alias for check
                if (args.length < 2) {
                    msg(sender, "&cUsage: /uc list <player>");
                    return true;
                }
                return onCommand(sender, command, label, new String[]{"check", args[1]});
            }
            case "clear" -> {
                if (args.length < 2) {
                    msg(sender, "&cUsage: /uc clear <player> [key]");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    msg(sender, "&cPlayer not found.");
                    return true;
                }
                UUID uuid = target.getUniqueId();

                if (args.length >= 3) {
                    String key = args[2];
                    cooldowns.clear(uuid, key);
                    msg(sender, plugin.getConfig().getString("messages.cleared-key", "&aCooldown cleared: %key%").replace("%key%", key));
                } else {
                    cooldowns.clearAll(uuid);
                    msg(sender, plugin.getConfig().getString("messages.cleared"));
                }
                storage.saveSafely();
                return true;
            }
            default -> {
                msg(sender, plugin.getConfig().getString("messages.unknown-subcommand"));
                return true;
            }
        }
    }

    private void msg(CommandSender sender, String raw) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        sender.sendMessage(Text.color(prefix + (raw == null ? "" : raw)));
    }
}
