package com.joinussmp.unicooldown.cooldown;

import java.util.List;

public record CooldownRule(
        String id,
        RuleType type,
        String matchKey,
        String sharedKey,
        long durationMillis,
        List<String> worlds,
        List<String> disabledWorlds,
        String bypassPermission,
        String message,
        String disabledMessage
) {
    public String effectiveKey() {
        return (sharedKey == null || sharedKey.isBlank()) ? id : sharedKey;
    }

    public boolean worldAllowed(String worldName) {
        if (worlds == null || worlds.isEmpty()) return true;
        for (String w : worlds) {
            if (w != null && w.equalsIgnoreCase(worldName)) return true;
        }
        return false;
    }

    public boolean isDisabledInWorld(String worldName) {
        if (disabledWorlds == null || disabledWorlds.isEmpty()) return false;
        for (String w : disabledWorlds) {
            if (w != null && w.equalsIgnoreCase(worldName)) return true;
        }
        return false;
    }
}
