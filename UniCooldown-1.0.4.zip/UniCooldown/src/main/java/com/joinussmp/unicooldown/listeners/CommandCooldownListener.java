package com.joinussmp.unicooldown.listeners;

import com.joinussmp.unicooldown.Text;
import com.joinussmp.unicooldown.cooldown.CooldownManager;
import com.joinussmp.unicooldown.cooldown.CooldownRule;
import com.joinussmp.unicooldown.cooldown.RuleRegistry;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;

import java.util.Locale;

public final class CommandCooldownListener implements Listener {
    private final Plugin plugin;
    private final CooldownManager cooldowns;
    private final RuleRegistry rules;

    public CommandCooldownListener(Plugin plugin, CooldownManager cooldowns, RuleRegistry rules) {
        this.plugin = plugin;
        this.cooldowns = cooldowns;
        this.rules = rules;
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();

        // global bypass
        if (player.hasPermission("unicooldown.bypass")) return;

        String msg = event.getMessage();
        if (msg == null || msg.length() < 2 || msg.charAt(0) != '/') return;

        String withoutSlash = msg.substring(1).trim();
        if (withoutSlash.isEmpty()) return;

        String base = withoutSlash.split("\\s+")[0].toLowerCase(Locale.ROOT);
        CooldownRule rule = rules.commandRule(base);
        if (rule == null) return;

        // Disabled-in-worlds gate (blocks the command entirely)
        String worldName = player.getWorld().getName();
        if (rule.isDisabledInWorld(worldName)) {
            if (rule.bypassPermission() != null && !rule.bypassPermission().isBlank() && player.hasPermission(rule.bypassPermission())) return;
            String prefix = plugin.getConfig().getString("messages.prefix", "");
            String text = (rule.disabledMessage() == null || rule.disabledMessage().isBlank())
                    ? plugin.getConfig().getString("messages.disabled-in-world", "&cYou cannot use that command in this world.")
                    : rule.disabledMessage();

            text = text.replace("%command%", base).replace("%key%", rule.effectiveKey()).replace("%world%", worldName);
            player.sendMessage(Text.color(prefix + text));
            event.setCancelled(true);
            return;
        }

        if (!rule.worldAllowed(worldName)) return;
        if (rule.bypassPermission() != null && !rule.bypassPermission().isBlank() && player.hasPermission(rule.bypassPermission())) return;

        String key = rule.effectiveKey();
        long remaining = cooldowns.remainingMillis(player.getUniqueId(), key);
        if (remaining > 0) {
            long secondsLeft = (long) Math.ceil(remaining / 1000.0);
            String prefix = plugin.getConfig().getString("messages.prefix", "");
            String text = (rule.message() == null || rule.message().isBlank())
                    ? plugin.getConfig().getString("messages.blocked-default", "&cPlease wait %time%s.")
                    : rule.message();

            text = text.replace("%time%", String.valueOf(secondsLeft))
                       .replace("%command%", base)
                       .replace("%key%", key)
                       .replace("%world%", worldName);

            player.sendMessage(Text.color(prefix + text));
            event.setCancelled(true);
            return;
        }

        cooldowns.set(player.getUniqueId(), key, rule.durationMillis());
    }
}
