package com.joinussmp.unicooldown;

import com.joinussmp.unicooldown.commands.UniCooldownCommand;
import com.joinussmp.unicooldown.cooldown.CooldownManager;
import com.joinussmp.unicooldown.cooldown.RuleRegistry;
import com.joinussmp.unicooldown.listeners.CommandCooldownListener;
import com.joinussmp.unicooldown.listeners.ItemCooldownListener;
import com.joinussmp.unicooldown.storage.CooldownStorage;
import org.bukkit.plugin.java.JavaPlugin;

public final class UniCooldownPlugin extends JavaPlugin {
    private CooldownManager cooldownManager;
    private RuleRegistry ruleRegistry;
    private CooldownStorage storage;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.cooldownManager = new CooldownManager();
        this.ruleRegistry = new RuleRegistry(this);
        this.storage = new CooldownStorage(this, cooldownManager);

        ruleRegistry.reload();

        if (getConfig().getBoolean("storage.persist", true)) {
            storage.load();
            long intervalSeconds = Math.max(10, getConfig().getLong("storage.save-interval-seconds", 60));
            getServer().getScheduler().runTaskTimerAsynchronously(
                    this,
                    () -> storage.saveSafely(),
                    intervalSeconds * 20L,
                    intervalSeconds * 20L
            );
        }

        // Listeners
        getServer().getPluginManager().registerEvents(new CommandCooldownListener(this, cooldownManager, ruleRegistry), this);
        getServer().getPluginManager().registerEvents(new ItemCooldownListener(this, cooldownManager, ruleRegistry), this);

        // Command
        getCommand("unicooldown").setExecutor(new UniCooldownCommand(this, cooldownManager, ruleRegistry, storage));
    }

    @Override
    public void onDisable() {
        if (getConfig().getBoolean("storage.persist", true)) {
            storage.saveSafely();
        }
    }

    public void reloadAll() {
        reloadConfig();
        ruleRegistry.reload();
    }
}
