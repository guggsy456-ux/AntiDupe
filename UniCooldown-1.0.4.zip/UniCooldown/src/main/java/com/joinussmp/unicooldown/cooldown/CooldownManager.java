package com.joinussmp.unicooldown.cooldown;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownManager {
    // uuid -> (key -> expiryMillis)
    private final ConcurrentHashMap<UUID, ConcurrentHashMap<String, Long>> data = new ConcurrentHashMap<>();

    public long now() {
        return System.currentTimeMillis();
    }

    public long remainingMillis(UUID uuid, String key) {
        Long exp = data.getOrDefault(uuid, new ConcurrentHashMap<>()).get(key);
        if (exp == null) return 0L;
        long rem = exp - now();
        return Math.max(0L, rem);
    }

    public void set(UUID uuid, String key, long durationMillis) {
        if (durationMillis <= 0) return;
        data.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                .put(key, now() + durationMillis);
    }

    public void clear(UUID uuid, String key) {
        var map = data.get(uuid);
        if (map == null) return;
        map.remove(key);
        if (map.isEmpty()) data.remove(uuid);
    }

    public void clearAll(UUID uuid) {
        data.remove(uuid);
    }

    public Map<String, Long> getAll(UUID uuid) {
        var map = data.get(uuid);
        if (map == null) return Collections.emptyMap();
        return Collections.unmodifiableMap(map);
    }

    public Map<UUID, Map<String, Long>> snapshotAll() {
        // used for storage; shallow snapshot
        Map<UUID, Map<String, Long>> snap = new ConcurrentHashMap<>();
        for (var e : data.entrySet()) {
            snap.put(e.getKey(), new ConcurrentHashMap<>(e.getValue()));
        }
        return snap;
    }

    public void loadSnapshot(Map<UUID, Map<String, Long>> snapshot) {
        data.clear();
        for (var e : snapshot.entrySet()) {
            data.put(e.getKey(), new ConcurrentHashMap<>(e.getValue()));
        }
    }

    public void cleanupExpired() {
        long t = now();
        for (var e : data.entrySet()) {
            e.getValue().entrySet().removeIf(x -> x.getValue() == null || x.getValue() <= t);
            if (e.getValue().isEmpty()) data.remove(e.getKey());
        }
    }
}
