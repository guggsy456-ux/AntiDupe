package com.joinussmp.unicooldown.storage;

import com.joinussmp.unicooldown.cooldown.CooldownManager;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CooldownStorage {
    private final Plugin plugin;
    private final CooldownManager cooldowns;
    private final File file;

    public CooldownStorage(Plugin plugin, CooldownManager cooldowns) {
        this.plugin = plugin;
        this.cooldowns = cooldowns;
        this.file = new File(plugin.getDataFolder(), "cooldowns.yml");
    }

    public void load() {
        if (!file.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        Map<UUID, Map<String, Long>> snapshot = new HashMap<>();

        var root = yml.getConfigurationSection("players");
        if (root != null) {
            for (String uuidStr : root.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    var sec = root.getConfigurationSection(uuidStr);
                    if (sec == null) continue;

                    Map<String, Long> map = new HashMap<>();
                    for (String key : sec.getKeys(false)) {
                        long exp = sec.getLong(key, 0L);
                        if (exp > System.currentTimeMillis()) {
                            map.put(key, exp);
                        }
                    }
                    if (!map.isEmpty()) snapshot.put(uuid, map);
                } catch (IllegalArgumentException ignored) {}
            }
        }

        cooldowns.loadSnapshot(snapshot);
        plugin.getLogger().info("Loaded cooldowns for " + snapshot.size() + " player(s).");
    }

    public void saveSafely() {
        try {
            save();
        } catch (Exception ex) {
            plugin.getLogger().warning("Failed to save cooldowns.yml: " + ex.getMessage());
        }
    }

    public void save() throws IOException {
        if (!plugin.getDataFolder().exists()) {
            //noinspection ResultOfMethodCallIgnored
            plugin.getDataFolder().mkdirs();
        }

        cooldowns.cleanupExpired();

        YamlConfiguration yml = new YamlConfiguration();
        var root = yml.createSection("players");

        for (var e : cooldowns.snapshotAll().entrySet()) {
            var sec = root.createSection(e.getKey().toString());
            for (var kv : e.getValue().entrySet()) {
                sec.set(kv.getKey(), kv.getValue());
            }
        }

        yml.save(file);
    }
}
