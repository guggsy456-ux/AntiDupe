package com.joinussmp.unicooldown.cooldown;

public enum RuleType {
    COMMAND,
    ITEM
}
