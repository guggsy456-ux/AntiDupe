package com.joinussmp.unicooldown.cooldown;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

import java.util.*;

public final class RuleRegistry {
    private final Plugin plugin;

    private final Map<String, CooldownRule> commandRules = new HashMap<>(); // command -> rule
    private final Map<Material, CooldownRule> itemRules = new HashMap<>();  // material -> rule

    public RuleRegistry(Plugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        commandRules.clear();
        itemRules.clear();

        ConfigurationSection root = plugin.getConfig().getConfigurationSection("cooldowns");
        if (root == null) return;

        // Commands
        ConfigurationSection cmd = root.getConfigurationSection("commands");
        if (cmd != null) {
            for (String key : cmd.getKeys(false)) {
                ConfigurationSection s = cmd.getConfigurationSection(key);
                if (s == null) continue;

                long seconds = Math.max(0L, s.getLong("seconds", 0L));
                String shared = s.getString("shared-key", "cmd:" + key.toLowerCase(Locale.ROOT));
                List<String> worlds = s.getStringList("worlds");
                List<String> disabledWorlds = s.getStringList("disable-in-worlds");
                String bypass = s.getString("bypass-permission", "unicooldown.bypass." + key.toLowerCase(Locale.ROOT));
                String msg = s.getString("message", plugin.getConfig().getString("messages.blocked-default"));
                String disabledMsg = s.getString("disabled-message", plugin.getConfig().getString("messages.disabled-in-world"));

                CooldownRule rule = new CooldownRule(
                        "command:" + key.toLowerCase(Locale.ROOT),
                        RuleType.COMMAND,
                        key.toLowerCase(Locale.ROOT),
                        shared,
                        seconds * 1000L,
                        worlds,
                        disabledWorlds,
                        bypass,
                        msg,
                        disabledMsg
                );
                commandRules.put(key.toLowerCase(Locale.ROOT), rule);
            }
        }

        // Items
        ConfigurationSection items = root.getConfigurationSection("items");
        if (items != null) {
            for (String matKey : items.getKeys(false)) {
                ConfigurationSection s = items.getConfigurationSection(matKey);
                if (s == null) continue;

                Material mat;
                try {
                    mat = Material.valueOf(matKey.toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("Unknown Material in cooldowns.items: " + matKey);
                    continue;
                }

                long seconds = Math.max(0L, s.getLong("seconds", 0L));
                String shared = s.getString("shared-key", "item:" + matKey.toLowerCase(Locale.ROOT));
                List<String> disabledWorlds = s.getStringList("disable-in-worlds");
                String bypass = s.getString("bypass-permission", "unicooldown.bypass." + matKey.toLowerCase(Locale.ROOT));
                String msg = s.getString("message", plugin.getConfig().getString("messages.blocked-default"));
                String disabledMsg = s.getString("disabled-message", plugin.getConfig().getString("messages.disabled-in-world"));

                CooldownRule rule = new CooldownRule(
                        "item:" + matKey.toLowerCase(Locale.ROOT),
                        RuleType.ITEM,
                        matKey.toUpperCase(Locale.ROOT),
                        shared,
                        seconds * 1000L,
                        List.of(),
                        disabledWorlds,
                        bypass,
                        msg,
                        disabledMsg
                );
                itemRules.put(mat, rule);
            }
        }
    }

    public CooldownRule commandRule(String command) {
        if (command == null) return null;
        return commandRules.get(command.toLowerCase(Locale.ROOT));
    }

    public CooldownRule itemRule(Material material) {
        return itemRules.get(material);
    }

    public Collection<CooldownRule> allRules() {
        List<CooldownRule> all = new ArrayList<>();
        all.addAll(commandRules.values());
        all.addAll(itemRules.values());
        return all;
    }
}
