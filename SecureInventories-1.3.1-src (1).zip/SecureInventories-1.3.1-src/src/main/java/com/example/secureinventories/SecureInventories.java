package com.example.secureinventories;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class SecureInventories extends JavaPlugin {

    private SecureInventoriesListener listener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.listener = new SecureInventoriesListener(this);
        getServer().getPluginManager().registerEvents(listener, this);
        getLogger().info("SecureInventories enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("SecureInventories disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("secureinventories")) return false;

        if (args.length == 0) {
            sender.sendMessage(color("&7Usage: &f/secureinventories <reload|status|inspect|pardon|rollback|quarantine|unquarantine>"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                reloadConfig();
                listener.reloadRuntimeConfig();
                sender.sendMessage(color("&aSecureInventories config reloaded."));
                return true;
            }
            case "status" -> {
                boolean enabled = getConfig().getBoolean("enabled", true);
                sender.sendMessage(color("&7SecureInventories: " + (enabled ? "&aENABLED" : "&cDISABLED")));
                sender.sendMessage(color("&7Action: &f" + getConfig().getString("action", "ROLLBACK")));
                sender.sendMessage(color("&7Ledger: &f" + getConfig().getBoolean("ledger.enabled", true)));
                sender.sendMessage(color("&7Shulker deep scan: &f" + getConfig().getBoolean("deepScanShulkers.enabled", true)));
                sender.sendMessage(color("&7World ignore: &f" + getConfig().getStringList("worldsIgnore")));
                return true;
            }
            case "inspect" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&7Usage: &f/secureinventories inspect <player>"));
                    return true;
                }
                Player target = getServer().getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(color("&cPlayer not online."));
                    return true;
                }
                listener.sendInspect(sender, target);
                return true;
            }
            case "pardon" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&7Usage: &f/secureinventories pardon <player|uuid>"));
                    return true;
                }
                listener.pardon(sender, args[1]);
                return true;
            }
            case "rollback" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&7Usage: &f/secureinventories rollback <player> [last]"));
                    return true;
                }
                String mode = (args.length >= 3) ? args[2] : "last";
                listener.rollbackCommand(sender, args[1], mode);
                return true;
            }
            case "quarantine" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&7Usage: &f/secureinventories quarantine <player>"));
                    return true;
                }
                Player target = getServer().getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(color("&cPlayer not online."));
                    return true;
                }
                listener.forceQuarantine(target, sender.getName());
                sender.sendMessage(color("&aQuarantined " + target.getName()));
                return true;
            }
            case "unquarantine" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&7Usage: &f/secureinventories unquarantine <player>"));
                    return true;
                }
                Player target = getServer().getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(color("&cPlayer not online."));
                    return true;
                }
                listener.unquarantine(target, sender.getName());
                sender.sendMessage(color("&aUnquarantined " + target.getName()));
                return true;
            }
            default -> {
                sender.sendMessage(color("&7Usage: &f/secureinventories <reload|status|inspect|pardon|rollback|quarantine|unquarantine>"));
                return true;
            }
        }
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
