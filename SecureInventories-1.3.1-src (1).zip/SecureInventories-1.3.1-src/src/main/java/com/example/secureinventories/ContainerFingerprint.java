package com.example.secureinventories;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

public final class ContainerFingerprint {

    private final EnumMap<Material, Integer> counts;

    public ContainerFingerprint(EnumMap<Material, Integer> counts) {
        this.counts = counts;
    }

    public static ContainerFingerprint capture(Inventory inv, Set<Material> ignore) {
        EnumMap<Material, Integer> map = new EnumMap<>(Material.class);
        ItemStack[] items = inv.getContents();
        if (items != null) {
            for (ItemStack it : items) {
                if (it == null) continue;
                Material m = it.getType();
                if (m.isAir()) continue;
                if (ignore != null && ignore.contains(m)) continue;
                map.merge(m, it.getAmount(), Integer::sum);
            }
        }
        return new ContainerFingerprint(map);
    }

    public static EnumMap<Material, Integer> delta(ContainerFingerprint after, ContainerFingerprint before) {
        EnumMap<Material, Integer> d = new EnumMap<>(Material.class);
        for (Map.Entry<Material, Integer> e : after.counts.entrySet()) {
            Material m = e.getKey();
            int a = e.getValue();
            int b = before.counts.getOrDefault(m, 0);
            int diff = a - b;
            if (diff != 0) d.put(m, diff);
        }
        for (Map.Entry<Material, Integer> e : before.counts.entrySet()) {
            Material m = e.getKey();
            if (after.counts.containsKey(m)) continue;
            d.put(m, -e.getValue());
        }
        return d;
    }
}
